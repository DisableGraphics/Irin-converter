------------------------------------ IRIN CONVERTER ---------------------------
What is IRIN CONVERTER?

A simple, yet effective imagemagick frontend.
ImageMagick is a program for converting between different image types. 
What images can I convert with this?
The only ones supported now are .pdf
In next releases there will be more files
